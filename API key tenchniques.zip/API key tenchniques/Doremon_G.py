import turtle

def draw_circle(color, radius, x, y):
    turtle.penup()
    turtle.fillcolor(color)
    turtle.goto(x, y)
    turtle.pendown()
    turtle.begin_fill()
    turtle.circle(radius)
    turtle.end_fill()

def draw_doraemon():
    turtle.speed(10)
    
    # Head (Blue)
    draw_circle("#0096da", 100, 0, -100)
    
    # Face (White)
    draw_circle("white", 80, 0, -80)
    
    # Eyes
    # Left eye
    draw_circle("white", 15, -15, 20)
    draw_circle("black", 5, -10, 30)
    # Right eye
    draw_circle("white", 15, 15, 20)
    draw_circle("black", 5, 10, 30)
    
    # Nose
    draw_circle("#e70012", 8, 0, 15)
    
    # Mouth and Philtrum
    turtle.penup()
    turtle.goto(0, 15)
    turtle.setheading(270)
    turtle.pendown()
    turtle.forward(40)
    
    # Smile
    turtle.penup()
    turtle.goto(-40, -5)
    turtle.pendown()
    turtle.setheading(-60)
    turtle.circle(45, 120)
    
    # Whiskers
    whisker_positions = [(-15, 5, 160), (-15, 0, 180), (-15, -5, 200),
                         (15, 5, 20), (15, 0, 0), (15, -5, -20)]
    
    for x, y, angle in whisker_positions:
        turtle.penup()
        turtle.goto(x, y)
        turtle.setheading(angle)
        turtle.pendown()
        turtle.forward(40)

    turtle.hideturtle()
    turtle.done()

if __name__ == "__main__":
    draw_doraemon()