import turtle

# Setup screen
screen = turtle.Screen()
screen.title("Doraemon Art")
screen.bgcolor("white")

pen = turtle.Turtle()
pen.speed(0)
pen.width(3)

# Helper function to draw circle
def draw_circle(color, radius, x, y):
    pen.penup()
    pen.goto(x, y - radius)
    pen.pendown()
    pen.color("black", color)
    pen.begin_fill()
    pen.circle(radius)
    pen.end_fill()

# Head
draw_circle("deepskyblue", 150, 0, 100)

# Face (white)
draw_circle("white", 120, 0, 80)

# Eyes
draw_circle("white", 25, -40, 160)
draw_circle("white", 25, 40, 160)

# Eyeballs
draw_circle("black", 10, -35, 155)
draw_circle("black", 10, 45, 155)

# Nose
draw_circle("red", 15, 0, 130)

# Nose line
pen.penup()
pen.goto(0, 115)
pen.pendown()
pen.goto(0, 40)

# Mouth
pen.penup()
pen.goto(-60, 60)
pen.setheading(-60)
pen.pendown()
pen.circle(70, 120)

# Whiskers
def whisker(x, y, angle):
    pen.penup()
    pen.goto(x, y)
    pen.setheading(angle)
    pen.pendown()
    pen.forward(80)

for y in [90, 70, 50]:
    whisker(-20, y, 180)
    whisker(20, y, 0)

# Bell
draw_circle("yellow", 20, 0, 20)

pen.hideturtle()
turtle.done()