api_key="your_api_key_here"

import os
from dotenv import load_dotenv

load_dotenv() 
api_key = os.getenv('API_KEY')

#Technique - 3 to secure API keys
{
    "API_KEY":"your_api_key_here"
    
}