from flask import Flask, render_template, request
from model import init_db, self_user, check_user

app = Flask(__name__)
app.secret_key = 'secret123'

# Initialize database
init_db()

@app.route('/')
def home():
    return render_template('index.html')

# Register user
@app.route('/login', methods=['POST'])
def register():
    username = request.form['username']
    password = request.form['password']
    self_user(username, password)
    return render_template('index.html', message="User registered successfully.")

# Login check
@app.route('/check', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    if check_user(username, password):
        return render_template('login.html', message="Login successful.")
    else:
        return render_template('login.html', message="Invalid credentials.")

@app.route('/login.page')
def login_page():
    return render_template('login.html')

if __name__ == '__main__':
    app.run(debug=True)
